import AreasClient from './AreasClient';

export default function AreasPage() {
  return (
    <main>
      <AreasClient />
    </main>
  );
}
